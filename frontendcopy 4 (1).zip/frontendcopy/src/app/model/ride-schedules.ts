import { Time } from "@angular/common";

export interface RideSchedules {
  isApproved: string,
  id: number;
  rideFrom: string;
  rideTo: string;
  ridedateTime: string;
  rideTime: string;
  rideFare: number;
  vehicleRegistrationNo: string;
  motoristUserId: number;
  noOfSeatsAvailable: number;

}

export class FareParameters {
    distance: number}

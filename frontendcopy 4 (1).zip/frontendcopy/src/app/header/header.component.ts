import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent{
  
  role:string='';
  loggedin:boolean=false;

  constructor(private authService: AuthenticationService,private router:Router){
    this.role=sessionStorage.getItem('role');
    this.loggedin=authService.isUserLoggedIn();
    console.log(this.role);
    console.log(this.loggedin);
  }


  logOut(){
    console.log(this.role);
    this.authService.logOut();
    this.router.navigate(['/login']);

    setTimeout(()=>{
      window.location.reload();
      },100); 
  }



 
  
  



}

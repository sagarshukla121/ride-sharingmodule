import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent{

  username= ''
  password= ''
  invalidLogin= false;
  user:User;
  

  constructor(private router:Router,private loginservice: AuthenticationService){
  
  }

  checkLogin() {
    this.loginservice.authenticate(this.username, this.password).subscribe({
      next:isAuthenticated => {
        if (isAuthenticated) {
            this.router.navigate(['/home']);
        }
        else {
            this.invalidLogin = true;
            this.username = '';
            this.password = '';
            window.alert("Invalid username and password");
        }
    }
  
  });
  }
}



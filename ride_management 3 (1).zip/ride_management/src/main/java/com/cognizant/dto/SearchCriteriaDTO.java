package com.cognizant.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class SearchCriteriaDTO {



	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String from;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String to;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int minPrice;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int maxPrice;

	private int availableSeats;

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public int getMinPrice() {
		return minPrice;
	}

	public void setMinPrice(int minPrice) {
		this.minPrice = minPrice;
	}

	public int getMaxPrice() {
		return maxPrice;
	}

	public void setMaxPrice(int maxPrice) {
		this.maxPrice = maxPrice;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

}

package com.cognizant.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Range;

public class BookingsDTO {
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int id;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int bookedOn;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int riderUserId;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	@Range(min=1,max=2)
	private int noOfSeats;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int totalAmount;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String paymentMode;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int rideSchedulesId;

	public int getRideSchedulesId() {
		return rideSchedulesId;
	}

	public void setRideSchedulesId(int rideSchedulesId) {
		this.rideSchedulesId = rideSchedulesId;
	}

	public int getId() {
		
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBookedOn() {
		return bookedOn;
	}

	public void setBookedOn(int bookedOn) {
		this.bookedOn = bookedOn;
	}

	public int getRiderUserId() {
		return riderUserId;
	}

	public void setRiderUserId(int riderUserId) {
		this.riderUserId = riderUserId;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

}

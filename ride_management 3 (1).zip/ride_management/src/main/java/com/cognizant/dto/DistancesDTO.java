package com.cognizant.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class DistancesDTO {
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int id;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String from;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String to;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int distanceInKMS;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public int getDistanceInKMS() {
		return distanceInKMS;
	}

	public void setDistanceInKMS(int distanceInKMS) {
		this.distanceInKMS = distanceInKMS;
	}


}

package com.cognizant.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class RideSchedulesDTO {

	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String isApproved;

	@NotNull(message = "{com.cognizant.dto.NotBlank.error}")
	private int id;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String rideFrom;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String rideTo;

	@FutureOrPresent(message = "{com.cognizant.dto.FutureOrPresent.error}")
	private LocalDate rideStartsOn;

	@FutureOrPresent(message = "{com.cognizant.dto.FutureOrPresent.error}")
	private LocalTime rideTime;

	private int rideFare;

	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	@Size(min = 10,max = 10,message = "{com.cognizant.dto.RideSchedulesDTO.vehicleRegistrationNo.length}")
	private String vehicleRegistrationNo;

	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int motoristUserId;

	private int noOfSeatsAvailable;

	public String getIsApproved() {return isApproved;}

	public void setIsApproved(String isApproved) {this.isApproved = isApproved;}


	public int getId() {return id;}

	public void setId(int id) {this.id = id;}

	public String getRideFrom() {
		return rideFrom;
	}

	public void setRideFrom(String rideFrom) {
		this.rideFrom = rideFrom;
	}

	public String getRideTo() {
		return rideTo;
	}

	public void setRideTo(String rideTo) {
		this.rideTo = rideTo;
	}

	public LocalDate getRideStartsOn() {
		return rideStartsOn;
	}

	public void setRideStartsOn(LocalDate rideStartsOn) {
		this.rideStartsOn = rideStartsOn;
	}

	public LocalTime getRideTime() {
		return rideTime;
	}

	public void setRideTime(LocalTime rideTime) {
		this.rideTime = rideTime;
	}

	public int getRideFare() {
		return rideFare;
	}

	public void setRideFare(int rideFare) {
		this.rideFare = rideFare;
	}

	public String getVehicleRegistrationNo() {
		return vehicleRegistrationNo;
	}

	public void setVehicleRegistrationNo(String vehicleRegistrationNo) {
		this.vehicleRegistrationNo = vehicleRegistrationNo;
	}

	public int getMotoristUserId() {
		return motoristUserId;
	}

	public void setMotoristUserId(int motoristUserId) {
		this.motoristUserId = motoristUserId;
	}

	public int getNoOfSeatsAvailable() {
		return noOfSeatsAvailable;
	}

	public void setNoOfSeatsAvailable(int noOfSeatsAvailable) {
		this.noOfSeatsAvailable = noOfSeatsAvailable;
	}

}

package com.cognizant.entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Ride_Schedules")
public class RideSchedules {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Ride_Schedules_Id")
	private int id;
	@Column(name = "Ride_From")
	private String rideFrom;
	@Column(name = "Ride_To")
	private String rideTo;
	@Column(name = "Ride_Starts_On")
	private LocalDate rideStartsOn;
	@Column(name = "Ride_Time")
	private LocalTime rideTime;
	@Column(name = "Ride_Fare")
	private int rideFare;
	@Column(name = "Vehicle_Registration_No")
	private String vehicleRegistrationNo;
	@Column(name = "Motorist_User_Id")
	private int motoristUserId;
	@Column(name = "No_Of_Seats_Available")
	private int noOfSeatsAvailable;


	@OneToMany(mappedBy = "rideSchedules",cascade = CascadeType.ALL)
	private List<Bookings> booking;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRideFrom() {
		return rideFrom;
	}

	public void setRideFrom(String rideFrom) {
		this.rideFrom = rideFrom;
	}

	public String getRideTo() {
		return rideTo;
	}

	public void setRideTo(String rideTo) {
		this.rideTo = rideTo;
	}

	public LocalDate getRideStartsOn() {
		return rideStartsOn;
	}

	public void setRideStartsOn(LocalDate rideStartsOn) {
		this.rideStartsOn = rideStartsOn;
	}

	public LocalTime getRideTime() {
		return rideTime;
	}

	public void setRideTime(LocalTime string) {
		this.rideTime = string;
	}

	public int getRideFare() {
		return rideFare;
	}

	public void setRideFare(int rideFare) {
		this.rideFare = rideFare;
	}

	public String getVehicleRegistrationNo() {
		return vehicleRegistrationNo;
	}

	public void setVehicleRegistrationNo(String vehicleRegistrationNo) {
		this.vehicleRegistrationNo = vehicleRegistrationNo;
	}

	public int getMotoristUserId() {
		return motoristUserId;
	}

	public void setMotoristUserId(int motoristUserId) {
		this.motoristUserId = motoristUserId;
	}

	public int getNoOfSeatsAvailable() {
		return noOfSeatsAvailable;
	}

	public void setNoOfSeatsAvailable(int noOfSeatsAvailable) {
		this.noOfSeatsAvailable = noOfSeatsAvailable;
	}

	@Override
	public String toString() {
		return "RideSchedules [id=" + id + ", rideFrom=" + rideFrom + ", rideTo=" + rideTo + ", rideStartsOn="
				+ rideStartsOn + ", rideTime=" + rideTime + ", rideFare=" + rideFare + ", vehicleRegistrationNo="
				+ vehicleRegistrationNo + ", motoristIdUsed=" + motoristUserId + ", noOfSeatsAvailable="
				+ noOfSeatsAvailable + "]";
	}

}

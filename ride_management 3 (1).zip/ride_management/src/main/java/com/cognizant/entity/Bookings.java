package com.cognizant.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Bookings")
public class Bookings {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Bookings_Id")
	private int bookingid;
	@Column(name = "Booked_On")
	private int bookedOn;
	@Column(name = "Rider_User_Id")
	private int riderUserId;
	@Column(name = "No_Of_Seats")
	private int noOfSeats;
	@Column(name = "Total_Amount")
	private int totalAmount;
	@Column(name = "Payment_Mode")
	private String paymentMode;
//	@Column(name = "FK_RideSchedules")
//	private int rideSchedulesId;

	@ManyToOne
	@JoinColumn(name = "Ride_Schedules_Id")
	private RideSchedules rideSchedules;

	public int getBookingid() {
		return bookingid;
	}

	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}

	public int getBookedOn() {
		return bookedOn;
	}

	public void setBookedOn(int bookedOn) {
		this.bookedOn = bookedOn;
	}

	public int getRiderUserId() {
		return riderUserId;
	}

	public void setRiderUserId(int riderUserId) {
		this.riderUserId = riderUserId;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public RideSchedules getRideSchedules() {
		return rideSchedules;
	}

	public void setRideSchedules(RideSchedules rideSchedules) {
		this.rideSchedules = rideSchedules;
	}

//	@Override
//	public String toString() {
//		return "Booking [bookingid=" + bookingid + ", bookedOn=" + bookedOn + ", riderUserId=" + riderUserId
//				+ ", noOfSeats=" + noOfSeats + ", totalAmount=" + totalAmount + ", paymentMode=" + paymentMode
//				+ ", rideSchedulesId=" + rideSchedulesId + "]";
//	}

}

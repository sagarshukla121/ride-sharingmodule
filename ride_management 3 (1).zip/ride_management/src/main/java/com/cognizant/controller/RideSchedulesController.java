package com.cognizant.controller;

import com.cognizant.exception.NoOfSeatsLimitExceedException;
import com.cognizant.exception.SameFromAndToPlaceException;
import com.cognizant.dto.FareParametersDTO;
import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.exception.VehicleNotApprovedException;
import com.cognizant.service.RideSchedulesService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;

@RestController
@RequestMapping(value = "/api/rides")
public class RideSchedulesController {

    @Autowired
    RideSchedulesService rideSchedulesService;

    @PostMapping(value = "/schedule")
    public ResponseEntity<?> createNewRide(@Valid @RequestBody RideSchedulesDTO rideSchedulesDTO){
        try{
            RideSchedulesDTO rd = rideSchedulesService.insertRideSchedules(rideSchedulesDTO);
            return new ResponseEntity<>(rd, HttpStatus.OK);
        }catch (SameFromAndToPlaceException e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }catch (VehicleNotApprovedException e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }catch (NoOfSeatsLimitExceedException e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }

    }
    @GetMapping(value = "/calculatefare")
    public int calculateFare(FareParametersDTO fareParametersDTO){
        return rideSchedulesService.calculateFare(fareParametersDTO);

    }

    @GetMapping("/search")
    public List<RideSchedulesDTO> searchRide(@Valid @RequestBody SearchCriteriaDTO searchCriteriaDTO){

        return rideSchedulesService.searchRide(searchCriteriaDTO);

    }


}

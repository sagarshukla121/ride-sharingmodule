package com.cognizant.controller;

import com.cognizant.dto.BookingsDTO;
import com.cognizant.service.BookingsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/rides")
public class BookingsController {

    @Autowired
    BookingsService bookingsService;

    @PostMapping("/book")
    public ResponseEntity<?> getBookingId(@Valid @RequestBody BookingsDTO bookingsDTO){
       System.out.println(bookingsDTO);
        BookingsDTO bDTO = bookingsService.insertBookings(bookingsDTO);
        return new ResponseEntity<>(bDTO.getId(), HttpStatus.OK);
        //return ResponseEntity.ok(id);
    }

}

package com.cognizant.exception;

public class VehicleNotApprovedException extends RuntimeException{
    public VehicleNotApprovedException(String message) {
        super(message);
    }
}

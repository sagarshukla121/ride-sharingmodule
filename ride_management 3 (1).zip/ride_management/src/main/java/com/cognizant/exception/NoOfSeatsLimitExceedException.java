package com.cognizant.exception;

public class NoOfSeatsLimitExceedException extends RuntimeException{

    public NoOfSeatsLimitExceedException(String message) {
        super(message);
    }
}

package com.cognizant.service;

import java.util.List;

import com.cognizant.dto.DistancesDTO;

public interface DistancesService {
	
	public List<DistancesDTO> getAllDistance();
	
	

}

package com.cognizant.service;


import com.cognizant.dto.FareParametersDTO;
import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.entity.RideSchedules;

import java.util.HashSet;
import java.util.List;

public interface RideSchedulesService {
	
	RideSchedulesDTO insertRideSchedules(RideSchedulesDTO rideSchedulesdto);


	List<RideSchedulesDTO> searchRide(SearchCriteriaDTO searchCriteriaDTO);

	int calculateFare(FareParametersDTO fareParametersDTO);
}

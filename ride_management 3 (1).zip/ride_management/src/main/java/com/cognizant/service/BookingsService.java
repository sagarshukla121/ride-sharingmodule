package com.cognizant.service;

import com.cognizant.dto.BookingsDTO;

public interface BookingsService {
	public BookingsDTO insertBookings(BookingsDTO bookingsdto);

}

package com.cognizant.service;

import com.cognizant.exception.NoOfSeatsLimitExceedException;
import com.cognizant.exception.SameFromAndToPlaceException;
import com.cognizant.dto.FareParametersDTO;
import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.entity.Distances;
import com.cognizant.exception.VehicleNotApprovedException;
import com.cognizant.mapper.FareParametersMapper;
import com.cognizant.mapper.SearchCriteriaMapper;
import com.cognizant.repositories.DistancesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.entity.RideSchedules;
import com.cognizant.mapper.RideSchedulesMapper;
import com.cognizant.repositories.RideSchedulesRepository;

import java.util.*;

@Service
public class RideSchedulesServiceImpl implements RideSchedulesService {

	@Autowired
	private RideSchedulesMapper rsMapper;
	@Autowired
	private SearchCriteriaMapper scMapper;

	@Autowired
	private DistancesRepository distancesRepository;

	private FareParametersDTO fareParametersDTO;

	private SearchCriteriaDTO searchCriteriaDTO;


	@Autowired
	private RideSchedulesRepository rsRepository;

	@Autowired
	private FareParametersMapper fareParametersMapper;
	@Override
	public RideSchedulesDTO insertRideSchedules(RideSchedulesDTO rideSchedulesdto){

		fareParametersDTO = new FareParametersDTO();
		searchCriteriaDTO = new SearchCriteriaDTO();

		Distances distances = distancesRepository.findByFromAndTo(rideSchedulesdto.getRideFrom(), rideSchedulesdto.getRideTo());


		int maxNoOfSeats=4;
		fareParametersDTO.setDistance(distances.getDistanceInKMS());

		searchCriteriaDTO.setFrom(distances.getFrom());
		searchCriteriaDTO.setTo(distances.getTo());

		//convert the Dto object to entity
		RideSchedules rideSchedule = rsMapper.toRideSchedules(rideSchedulesdto);
		if(rideSchedulesdto.getRideFrom().equalsIgnoreCase(rideSchedulesdto.getRideTo())){
			throw new SameFromAndToPlaceException("From place and To place Should not be same");
		}
		if(rideSchedulesdto.getIsApproved().equals("rejected")){
			throw new VehicleNotApprovedException("Vehicle was not Approved by the security head");
		}
		if(rideSchedulesdto.getNoOfSeatsAvailable()>maxNoOfSeats){
			throw new NoOfSeatsLimitExceedException("The number of seats in a ride exceeded the limit");
		}
		// create a new Ride Schedule object
		RideSchedules createRideSchedule = rsRepository.save(rideSchedule);

		//now convert the entity object to dto and return it
		return rsMapper.toRideSchedulesDTO(createRideSchedule);

	}

	@Override
	public List<RideSchedulesDTO> searchRide(SearchCriteriaDTO searchCriteriaDTO) {

		ArrayList<RideSchedules> rideSchedulesArrayList = rsRepository.findByRideFromAndRideTo(searchCriteriaDTO.getFrom(), searchCriteriaDTO.getTo());
		Iterator<RideSchedules> rideSchedulesIterable = rideSchedulesArrayList.iterator();
		List<RideSchedulesDTO> rideSchedulesDTOList = new ArrayList<RideSchedulesDTO>();
		while (rideSchedulesIterable.hasNext()) {
			RideSchedules rideSchedules = rideSchedulesIterable.next();
			if (rideSchedules.getRideFare() >= searchCriteriaDTO.getMinPrice() && rideSchedules.getRideFare() <= searchCriteriaDTO.getMaxPrice() && rideSchedules.getNoOfSeatsAvailable()>= searchCriteriaDTO.getAvailableSeats()) {
				RideSchedulesDTO rideSchedulesDTO=rsMapper.toRideSchedulesDTO(rideSchedules);
				rideSchedulesDTOList.add(rideSchedulesDTO);
			}
		}
		return rideSchedulesDTOList;


	}


	@Override
	public int calculateFare(FareParametersDTO fareParametersDTO) {
		int farePerKm=10;

		return  farePerKm * fareParametersDTO.getDistance();
	}




}




insert into Distances(From_Place,To_Place,Distance_In_KMS) values('Kannur','Payyannur',38);
insert into Distances(From_Place,To_Place,Distance_In_KMS) values('Kozhikode','Kannur',92);
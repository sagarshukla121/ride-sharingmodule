package com.cognizant.service;

import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.entity.Distances;
import com.cognizant.entity.RideSchedules;
import com.cognizant.mapper.RideSchedulesMapper;
import com.cognizant.repositories.DistancesRepository;
import com.cognizant.repositories.RideSchedulesRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.mockito.Mockito.when;

public class TestRideSchedulesServiceImpl {

    @Mock
    DistancesRepository distancesRepository;

    @Mock
    RideSchedulesRepository rideSchedulesRepository;
    @InjectMocks
    RideSchedulesServiceImpl rideSchedulesService;

    @Mock
    RideSchedulesMapper rsMapper;
    @BeforeEach
    public void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void tearDown() throws Exception{
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void insertRideSchedules_Positive(){
        Distances distances = new Distances();
        distances.setDistanceInKMS(38);
        distances.setFrom("Kannur");
        distances.setTo("Payyanur");
        when(distancesRepository.findByFromAndTo(distances.getFrom(), distances.getTo())).thenReturn(distances);

        RideSchedulesDTO rideSchedulesDTO = new RideSchedulesDTO();
        rideSchedulesDTO.setRideFrom("Kannur");
        rideSchedulesDTO.setRideTo("Payyanur");
        rideSchedulesDTO.setRideStartsOn(LocalDate.now());
        rideSchedulesDTO.setRideTime(LocalTime.now());

        RideSchedules rideSchedules = new RideSchedules();
        rideSchedules.setRideFrom("Kannur");
        rideSchedules.setRideTo("Payyanur");
        rideSchedules.setRideStartsOn(LocalDate.now());
        rideSchedules.setRideTime(LocalTime.now());

        when(rsMapper.toRideSchedules(rideSchedulesDTO)).thenReturn(rideSchedules);

        RideSchedules createRideSchedules = new RideSchedules();
        createRideSchedules.setRideFrom("Kannur");
        createRideSchedules.setRideTo("Payyanur");
        createRideSchedules.setRideStartsOn(LocalDate.now());
        createRideSchedules.setRideTime(LocalTime.now());

        when(rideSchedulesRepository.save(rideSchedules)).thenReturn(createRideSchedules);

        RideSchedulesDTO rideSchedulesDTO1=new RideSchedulesDTO();
        rideSchedulesDTO1.setRideFrom("Kannur");
        rideSchedulesDTO1.setRideTo("Payyanur");
        rideSchedulesDTO1.setRideStartsOn(LocalDate.now());
        rideSchedulesDTO1.setRideTime(LocalTime.now());

        when(rsMapper.toRideSchedulesDTO(createRideSchedules)).thenReturn(rideSchedulesDTO1);

    }

    @Test
    public void calculateFare_Positive(){

    }


}

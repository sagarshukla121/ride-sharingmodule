package com.cognizant.service;

import com.cognizant.dto.BookingsDTO;
import com.cognizant.entity.Bookings;
import com.cognizant.mapper.BookingsMapper;
import com.cognizant.repositories.BookingsRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.when;

public class TestBookingsServiceImpl {
    @Mock
    BookingsRepository bookingsRepository;
    @InjectMocks
    BookingsServiceImpl bookingsService;
    @Mock
    BookingsMapper bMapper;
    @BeforeEach
    public void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void tearDown() throws Exception{
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void insertBookings_Positive(){
        BookingsDTO bookingsDTO = new BookingsDTO();
        bookingsDTO.setBookedOn(20);
        bookingsDTO.setRiderUserId(23);
        bookingsDTO.setNoOfSeats(2);
        bookingsDTO.setTotalAmount(100);
        bookingsDTO.setPaymentMode("upi");

        Bookings bookings = new Bookings();
        bookings.setBookedOn(20);
        bookings.setRiderUserId(23);
        bookings.setNoOfSeats(2);
        bookings.setTotalAmount(100);
        bookings.setPaymentMode("upi");

        when(bMapper.toBookings(bookingsDTO)).thenReturn(bookings);

        Bookings createBooking = new Bookings();
        createBooking.setBookedOn(20);
        createBooking.setRiderUserId(23);
        createBooking.setNoOfSeats(2);
        createBooking.setTotalAmount(100);
        createBooking.setPaymentMode("upi");

        when(bookingsRepository.save(bookings)).thenReturn(createBooking);

        BookingsDTO bookingsDTO1=new BookingsDTO();
        bookingsDTO1.setBookedOn(20);
        bookingsDTO1.setRiderUserId(23);
        bookingsDTO1.setNoOfSeats(2);
        bookingsDTO1.setTotalAmount(100);
        bookingsDTO1.setPaymentMode("upi");

        when(bMapper.toBookingsdto(createBooking));
    }

}

package com.cognizant.repositories;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.RideManagementApplication;
import com.cognizant.entity.Bookings;
import com.cognizant.repositories.BookingsRepository;

@DataJpaTest
@ContextConfiguration(classes = RideManagementApplication.class)
public class TestBookingsRepository {

	@Autowired
	private BookingsRepository bookingsRepository;

	@Autowired
	private TestEntityManager entityManager;

	@Test
	void testFindAllPositive() {

		Bookings b = new Bookings();
		b.setBookedOn(1);
		b.setRiderUserId(22);
		b.setNoOfSeats(4);
		b.setTotalAmount(100);
		b.setPaymentMode("UPI");
		entityManager.persist(b);
		Iterable<Bookings> it = bookingsRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}

	@Test
	void testFindAllNegative() {

		Iterable<Bookings> it = bookingsRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}

	@Test
	void testFindByIdPositive() {

		Bookings b = new Bookings();

		b.setBookedOn(1);
		b.setRiderUserId(22);
		b.setNoOfSeats(4);
		b.setTotalAmount(100);
		b.setPaymentMode("UPI");
		int id = entityManager.persist(b).getBookingid();
		Optional<Bookings> it = bookingsRepository.findById(id);
		assertTrue(it.isPresent());

	}

	@Test
	void testFindByIdNegative() {

		Optional<Bookings> it = bookingsRepository.findById(1);
		assertTrue(!it.isPresent());

	}

	@Test
	void testSavePositive() {

		Bookings b = new Bookings();
		b.setBookedOn(1);
		b.setRiderUserId(22);
		b.setNoOfSeats(4);
		b.setTotalAmount(100);
		b.setPaymentMode("UPI");
		int id = bookingsRepository.save(b).getBookingid();
		Optional<Bookings> it = bookingsRepository.findById(id);
		assertTrue(it.isPresent());

	}

	@Test
	void testDeletePositive() {

		Bookings b = new Bookings();
		b.setBookedOn(1);
		b.setRiderUserId(22);
		b.setNoOfSeats(4);
		b.setTotalAmount(100);
		b.setPaymentMode("UPI");
		entityManager.persist(b);
		bookingsRepository.delete(b);
		Optional<Bookings> it = bookingsRepository.findById(1);
		assertTrue(!it.isPresent());

	}

	@Test
	void testCount() {

		Bookings b = new Bookings();
		b.setBookedOn(1);
		b.setRiderUserId(22);
		b.setNoOfSeats(4);
		b.setTotalAmount(100);
		b.setPaymentMode("UPI");
		entityManager.persist(b);
		long actualCount = bookingsRepository.count();
		long expectedCount = 1;
		assertEquals(expectedCount, actualCount);

	}

}
